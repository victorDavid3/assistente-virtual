

const output = document.querySelector('#output');
const resp = document.querySelector('#resp');

var responder = "";


const synth = window.speechSynthesis; // chamada SpeechSynthesis API
        
        const selectVoices = document.querySelector('select'); // lista de vozes

        let voices = [];
        function getVoices() { 
          voices = synth.getVoices(); // armazena as vozes no array
          voices.forEach((voice, index) => {
            selectVoices.add(new Option(`${voice.name} (${voice.lang})`, index)); // adiciona as informações na lista de seleção..
          });
        }

        window.addEventListener('load', () => { // ao ser concluído..
          getVoices(); // carrega as vozes..
          if (synth.onvoiceschanged !== undefined)
            synth.onvoiceschanged = getVoices; // checa e atualiza o evento
        });



function ouvir() {
	const recognition = new webkitSpeechRecognition();
	recognition.interimResults = true;
	recognition.lang = "pt-BR";
	recognition.continuous = true;
	recognition.start();
	         
	recognition.onresult = function(event) {
	for (let i = event.resultIndex; i < event.results.length; i++) {

        if (event.results[i].isFinal) {
                const content = event.results[i][0].transcript.trim();
                output.textContent = content;
                resposta(content);

                
            }
        }

       
    }
}

function falar(responder){
    // dispara um evento ao clicar no botão!
      
          var utter = new SpeechSynthesisUtterance(responder); // responsável pelo que vai falar!
          utter.voice = voices[selectVoices.value]; // define qual será a voz..
          synth.speak(utter); // reproduz o audio!

}


function resposta(content){

content = content.toLowerCase();

	switch (content) {
    case "oi":
        responder = "Oi";
        break;
    case "abc":
        responder = "cba";
        break;
    case "cor azul":
        document.getElementById('quad').style.backgroundColor = 'blue';
        document.getElementById('quad2').style.backgroundColor = 'blue';
        responder = "cor azul";
        break;
    case "cor vermelha":
        document.getElementById('quad').style.backgroundColor = 'red';
        document.getElementById('quad2').style.backgroundColor = 'red';
        responder = "cor vermelha";
        break;
    case "cor verde":
        document.getElementById('quad').style.backgroundColor = 'green';
        document.getElementById('quad2').style.backgroundColor = 'green';
        responder = "cor verde";
        break;
    case "fundo verde":
        document.body.style.backgroundColor = 'green';
        responder = "fundo verde";
        break;
    case "fundo azul":
        document.body.style.backgroundColor = 'blue';
        responder = "fundo azul";
        break;
    case "fundo vermelho":
        document.body.style.backgroundColor = 'red';
        responder = "fundo vermelho";
        break;
    case "música":
        responder = "tocando perfect world";
        const music = new Audio('musicas/perfect world.mpeg');
        music.play();
        break;
    case "música dois":
        responder = "tocando Running Up That Hill";
        const musica = new Audio('musicas/Running Up That Hill.aac');
        musica.play();
        break;
    case "que horas são":    
        const horas = new Date();
        responder = horas.getHours() + ":" + horas.getMinutes();
        break;
    case "que dia é hoje":    
        const d = new Date();
        var mes = (d.getMonth() + 1);
        responder = d.getDate() + "/" + mes + "/" + d.getUTCFullYear();
        break;
    default:
        responder = "Não sei o que você esta falando";
        
     }

resp.textContent = responder;

falar(responder);


}




   



    
       


    
      